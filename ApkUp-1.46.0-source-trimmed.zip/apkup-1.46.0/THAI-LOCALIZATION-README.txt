ApkUp 1.46.0 - Thai localization

Changes:
- Added app/src/main/res/values-th/strings.xml with Thai translations for all 586 base string resources, including plural resources.
- Added Thai (th) to app/src/main/res/xml/locales_config.xml.
- Kept the original app name, package configuration, version code/name, and branding unchanged.

Language selection:
- On Android 10 and earlier, set the device language to Thai, then reopen ApkUp.
- On Android 13 and later, choose Thai in the app language settings if the system exposes per-app languages.

Build status:
- Resource XML was parsed and checked for missing keys and mismatched format placeholders.
- A local APK build could not be completed in this environment because the Gradle distribution could not be downloaded (network/DNS unavailable). Build this source with the project's Gradle wrapper in an online Android build environment.
