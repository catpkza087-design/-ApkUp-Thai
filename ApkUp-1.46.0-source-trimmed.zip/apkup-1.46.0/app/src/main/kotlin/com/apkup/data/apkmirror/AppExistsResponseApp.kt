package com.apkup.data.apkmirror

data class AppExistsResponseApp(
    val name: String = "",
    val description: String? = null,
    val link: String? = null
)
