package com.apkup.util

import com.apkup.data.ui.Screen
import kotlinx.coroutines.flow.MutableStateFlow


class Badger {

    private val badges = MutableStateFlow(mapOf(
        Screen.Apps.route to "",
        Screen.Updates.route to "",
        Screen.Settings.route to ""
    ))

    fun flow() = badges

    fun changeAppsBadge(number: String) = changeBadge(Screen.Apps.route, number)

    fun changeUpdatesBadge(number: String) = changeBadge(Screen.Updates.route, number)

    fun changeSettingsBadge(badge: String) = changeBadge(Screen.Settings.route, badge)

    private fun changeBadge(route: String, number: String) {
        val finalNumber = if (number.toIntOrNull() == 0) "" else number
        val newBadges = badges.value.toMutableMap()
        newBadges[route] = finalNumber
        badges.value = newBadges
    }

}
