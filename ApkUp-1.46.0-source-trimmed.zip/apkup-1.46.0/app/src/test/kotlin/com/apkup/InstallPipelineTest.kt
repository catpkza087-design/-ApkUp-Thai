package com.apkup

import com.apkup.data.ui.AppInstallStatus
import com.apkup.util.InstallLog
import com.apkup.util.InstallPart
import com.apkup.util.wrapStreamIfGzip
import com.aurora.gplayapi.model.AppFile
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.GZIPOutputStream

class InstallPipelineTest {

    @Test
    fun `wrapStreamIfGzip decompresses gzipped stream correctly`() {
        val originalText = "This is a simulated APK byte content compressed with GZIP."
        val originalBytes = originalText.toByteArray(Charsets.UTF_8)

        val byteOut = ByteArrayOutputStream()
        GZIPOutputStream(byteOut).use { it.write(originalBytes) }
        val gzippedBytes = byteOut.toByteArray()

        val input = ByteArrayInputStream(gzippedBytes)
        val wrapped = wrapStreamIfGzip(input)
        val decompressedBytes = wrapped.readBytes()

        assertArrayEquals(originalBytes, decompressedBytes)
    }

    @Test
    fun `wrapStreamIfGzip leaves standard raw zip apk stream intact`() {
        val rawApkBytes = byteArrayOf(0x50, 0x4B, 0x03, 0x04, 0x14, 0x00, 0x08, 0x00) // PK header
        val input = ByteArrayInputStream(rawApkBytes)
        val wrapped = wrapStreamIfGzip(input)
        val result = wrapped.readBytes()

        assertArrayEquals(rawApkBytes, result)
    }

    @Test
    fun `play files are sorted so BASE is first and splits follow`() {
        val splitConfig = AppFile(
            name = "split_config.arm64_v8a.apk",
            type = AppFile.Type.SPLIT,
            size = 1000L
        )
        val splitLang = AppFile(
            name = "split_config.de.apk",
            type = AppFile.Type.SPLIT,
            size = 500L
        )
        val baseFile = AppFile(
            name = "base.apk",
            type = AppFile.Type.BASE,
            size = 50000L
        )

        val unordered = listOf(splitConfig, splitLang, baseFile)
        val sorted = unordered.sortedWith(
            compareByDescending<AppFile> { it.type == AppFile.Type.BASE }
                .thenBy { it.name }
        )

        assertEquals(AppFile.Type.BASE, sorted[0].type)
        assertEquals("base.apk", sorted[0].name)
        assertEquals(AppFile.Type.SPLIT, sorted[1].type)
        assertEquals("split_config.arm64_v8a.apk", sorted[1].name)
        assertEquals(AppFile.Type.SPLIT, sorted[2].type)
        assertEquals("split_config.de.apk", sorted[2].name)
    }

    @Test
    fun `all install part filenames end with apk extension`() {
        val fileBase = AppFile(name = "", type = AppFile.Type.BASE)
        val fileSplitNoExt = AppFile(name = "split_config", type = AppFile.Type.SPLIT)
        val fileSplitWithExt = AppFile(name = "split_lang.apk", type = AppFile.Type.SPLIT)

        val files = listOf(fileBase, fileSplitNoExt, fileSplitWithExt)
        val parts = files.mapIndexed { index, file ->
            val partName = when {
                file.type == AppFile.Type.BASE -> "base.apk"
                file.name.endsWith(".apk") -> file.name
                file.name.isNotBlank() -> "${file.name}.apk"
                else -> "split_$index.apk"
            }
            InstallPart(partName) { ByteArrayInputStream(byteArrayOf(1, 2, 3)) }
        }

        assertEquals("base.apk", parts[0].name)
        assertEquals("split_config.apk", parts[1].name)
        assertEquals("split_lang.apk", parts[2].name)
        parts.forEach {
            assertTrue("Part name ${it.name} must end with .apk", it.name.endsWith(".apk"))
        }
    }

    @Test
    fun `changelog display conditions trigger correctly based on fresh install check`() {
        val currentVersionCode = 127L

        fun shouldShowChangelog(lastSeen: Long, isFreshInstall: Boolean): Boolean {
            return when {
                lastSeen == 0L && !isFreshInstall -> true
                lastSeen in 1 until currentVersionCode -> true
                lastSeen == 0L && isFreshInstall -> false
                else -> false
            }
        }

        // Scenario 1: Update from v1.26 where last_seen_version_code was 0L (not a fresh install)
        assertTrue(shouldShowChangelog(lastSeen = 0L, isFreshInstall = false))

        // Scenario 2: Normal subsequent update (e.g. from 125 to 127)
        assertTrue(shouldShowChangelog(lastSeen = 125L, isFreshInstall = false))

        // Scenario 3: True fresh install (firstInstallTime == lastUpdateTime)
        assertTrue(!shouldShowChangelog(lastSeen = 0L, isFreshInstall = true))

        // Scenario 4: Already seen current version (no re-trigger)
        assertTrue(!shouldShowChangelog(lastSeen = 127L, isFreshInstall = false))
    }

    @Test
    fun `InstallLog status flow has zero replay so restarted DownloadInstallService never receives stale cancel events`() = runBlocking {
        val log = InstallLog()
        log.emitStatus(AppInstallStatus(success = false, id = 1974986299, snack = false))

        assertTrue(
            "InstallLog.status replayCache must be empty (replay=0) so a newly started service does not replay prior cancel statuses",
            log.status().replayCache.isEmpty()
        )
    }

    @Test
    fun `Proguard rules keep KnownRepoEntry to prevent R8 LinkedTreeMap ClassCastException`() {
        val proguardFile = File("proguard-rules.pro").takeIf { it.exists() }
            ?: File("app/proguard-rules.pro")
        assertTrue("proguard-rules.pro must exist", proguardFile.exists())
        val content = proguardFile.readText()
        assertTrue(
            "proguard-rules.pro must keep com.apkup.repository.KnownRepoEntry",
            content.contains("-keep class com.apkup.repository.KnownRepoEntry")
        )
    }
}
